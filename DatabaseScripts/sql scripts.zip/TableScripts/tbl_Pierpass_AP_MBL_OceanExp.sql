
Create TABLE dbo.tbl_Pierpass_AP_MBL_OceanExp (
MBL_NO					VARCHAR(20),
Vendor                VARCHAR(200)    NOT NULL,
Billing_Code          VARCHAR(100)    NOT NULL,
Charges_Amount1       DECIMAL(10,2),
Charges_Amount        DECIMAL(10,2),
[Description]          VARCHAR(500)  
)
